﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form24 : Form
    {
        public Form24()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //Hola   -- (0)=H  (1)=o (2)=l (3)=a  (4)
            //La vida es Herm0sa
            var texto = textBox1.Text;
            var cantidadvocal = 0;
            var cantidadespacio = 0;
            var cantidadnumero = 0;
            var cantidadconsonante = 0;
            int ejem = 0;
            for (var i = 0; i <= texto.Length - 1; i++)
            {

                if (sabersiesvocal(texto.Substring(i, 1)))
                {
                    cantidadvocal = cantidadvocal + 1;
                }
                else
                {

                    if (texto.Substring(i, 1).Equals(" "))
                    {
                        cantidadespacio = cantidadespacio + 1;
                    }
                    else
                    {

                        if (int.TryParse(texto.Substring(i, 1), out ejem))
                        {
                            cantidadnumero = cantidadnumero + 1;
                        }
                        else
                        {
                            cantidadconsonante = cantidadconsonante + 1;

                        }
                    }
                }




            }

            label4.Text = "Vocales: " + cantidadvocal.ToString();
            label5.Text = "Consonantes: " + cantidadconsonante.ToString();
            label6.Text = "Espacios: " + cantidadespacio.ToString();



        }




        private Boolean sabersiesvocal(string caracter)
        {
            var letra = caracter;

            if ((letra == "a") || (letra == "e") || (letra == "i") || (letra == "o") || (letra == "u") ||
           (letra == "A") || (letra == "E") || (letra == "I") || (letra == "O") || (letra == "U"))


                return true;

            else

            {
                return false;
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            // mi nombre es samuel
            string cadena = textBox1.Text;

            textBox1.Text = new CultureInfo("es-ES").TextInfo.ToTitleCase(cadena);
        }

    }


          
    
}
