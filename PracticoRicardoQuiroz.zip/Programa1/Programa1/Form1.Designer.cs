﻿namespace Programa1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnCalculadora = new System.Windows.Forms.Button();
            this.btntablaMultiplicar = new System.Windows.Forms.Button();
            this.txtaprobado = new System.Windows.Forms.Button();
            this.txtpocitivo = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.primos = new System.Windows.Forms.Button();
            this.mayor3 = new System.Windows.Forms.Button();
            this.dias = new System.Windows.Forms.Button();
            this.vocal = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.pares = new System.Windows.Forms.Button();
            this.sueldo = new System.Windows.Forms.Button();
            this.categoria = new System.Windows.Forms.Button();
            this.impares = new System.Windows.Forms.Button();
            this.n = new System.Windows.Forms.Button();
            this.n1 = new System.Windows.Forms.Button();
            this.n2 = new System.Windows.Forms.Button();
            this.n3 = new System.Windows.Forms.Button();
            this.n4 = new System.Windows.Forms.Button();
            this.letra = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCalculadora
            // 
            this.btnCalculadora.Location = new System.Drawing.Point(650, 223);
            this.btnCalculadora.Name = "btnCalculadora";
            this.btnCalculadora.Size = new System.Drawing.Size(144, 63);
            this.btnCalculadora.TabIndex = 5;
            this.btnCalculadora.Text = "Calculadora";
            this.btnCalculadora.UseVisualStyleBackColor = true;
            this.btnCalculadora.Click += new System.EventHandler(this.BtnCalculadora_Click);
            // 
            // btntablaMultiplicar
            // 
            this.btntablaMultiplicar.Location = new System.Drawing.Point(486, 223);
            this.btntablaMultiplicar.Name = "btntablaMultiplicar";
            this.btntablaMultiplicar.Size = new System.Drawing.Size(144, 63);
            this.btntablaMultiplicar.TabIndex = 5;
            this.btntablaMultiplicar.Text = "Tabla de Multiplicar";
            this.btntablaMultiplicar.UseVisualStyleBackColor = true;
            this.btntablaMultiplicar.Click += new System.EventHandler(this.BtntablaMultiplicar_Click);
            // 
            // txtaprobado
            // 
            this.txtaprobado.Location = new System.Drawing.Point(737, 317);
            this.txtaprobado.Name = "txtaprobado";
            this.txtaprobado.Size = new System.Drawing.Size(129, 63);
            this.txtaprobado.TabIndex = 6;
            this.txtaprobado.Text = "verificar si el alumno esta aprobado o desaprobado";
            this.txtaprobado.UseVisualStyleBackColor = true;
            this.txtaprobado.Click += new System.EventHandler(this.Txtaprobado_Click);
            // 
            // txtpocitivo
            // 
            this.txtpocitivo.Location = new System.Drawing.Point(607, 319);
            this.txtpocitivo.Name = "txtpocitivo";
            this.txtpocitivo.Size = new System.Drawing.Size(112, 63);
            this.txtpocitivo.TabIndex = 7;
            this.txtpocitivo.Text = "comprobar si el numero es pocitivo o negativo";
            this.txtpocitivo.UseVisualStyleBackColor = true;
            this.txtpocitivo.Click += new System.EventHandler(this.Txtpocitivo_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(19, 226);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 60);
            this.button1.TabIndex = 8;
            this.button1.Text = "pares e impares";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // primos
            // 
            this.primos.Location = new System.Drawing.Point(150, 226);
            this.primos.Name = "primos";
            this.primos.Size = new System.Drawing.Size(144, 60);
            this.primos.TabIndex = 9;
            this.primos.Text = "mayor de dos numeros";
            this.primos.UseVisualStyleBackColor = true;
            this.primos.Click += new System.EventHandler(this.Primos_Click);
            // 
            // mayor3
            // 
            this.mayor3.Location = new System.Drawing.Point(319, 226);
            this.mayor3.Name = "mayor3";
            this.mayor3.Size = new System.Drawing.Size(129, 60);
            this.mayor3.TabIndex = 10;
            this.mayor3.Text = "mayor de 3";
            this.mayor3.UseVisualStyleBackColor = true;
            this.mayor3.Click += new System.EventHandler(this.Mayor3_Click);
            // 
            // dias
            // 
            this.dias.Location = new System.Drawing.Point(465, 317);
            this.dias.Name = "dias";
            this.dias.Size = new System.Drawing.Size(112, 60);
            this.dias.TabIndex = 11;
            this.dias.Text = "ingrese del 1 al 7 para saber que dia es ";
            this.dias.UseVisualStyleBackColor = true;
            this.dias.Click += new System.EventHandler(this.Dias_Click);
            // 
            // vocal
            // 
            this.vocal.Location = new System.Drawing.Point(19, 324);
            this.vocal.Name = "vocal";
            this.vocal.Size = new System.Drawing.Size(113, 53);
            this.vocal.TabIndex = 12;
            this.vocal.Text = "ingresar una letra para saber si es vocal o no";
            this.vocal.UseVisualStyleBackColor = true;
            this.vocal.Click += new System.EventHandler(this.Vocal_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(150, 324);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(125, 53);
            this.button5.TabIndex = 13;
            this.button5.Text = "contar del 1 al 10";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(304, 324);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(109, 53);
            this.button6.TabIndex = 14;
            this.button6.Text = "que cuente del 1 al n";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(465, 396);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 53);
            this.button2.TabIndex = 15;
            this.button2.Text = "que pida un numero y diga si es primo o no";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(19, 396);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(104, 53);
            this.button3.TabIndex = 16;
            this.button3.Text = "multiplos de 5";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // pares
            // 
            this.pares.Location = new System.Drawing.Point(150, 396);
            this.pares.Name = "pares";
            this.pares.Size = new System.Drawing.Size(104, 53);
            this.pares.TabIndex = 17;
            this.pares.Text = "que sume los numeros pares de 1 a n";
            this.pares.UseVisualStyleBackColor = true;
            this.pares.Click += new System.EventHandler(this.Pares_Click);
            // 
            // sueldo
            // 
            this.sueldo.Location = new System.Drawing.Point(304, 396);
            this.sueldo.Name = "sueldo";
            this.sueldo.Size = new System.Drawing.Size(109, 53);
            this.sueldo.TabIndex = 18;
            this.sueldo.Text = "calculando beneficios de un sueldo";
            this.sueldo.UseVisualStyleBackColor = true;
            this.sueldo.Click += new System.EventHandler(this.Sueldo_Click);
            // 
            // categoria
            // 
            this.categoria.Location = new System.Drawing.Point(465, 459);
            this.categoria.Name = "categoria";
            this.categoria.Size = new System.Drawing.Size(100, 53);
            this.categoria.TabIndex = 19;
            this.categoria.Text = "calcular sueldo segun su categoria";
            this.categoria.UseVisualStyleBackColor = true;
            this.categoria.Click += new System.EventHandler(this.Categoria_Click);
            // 
            // impares
            // 
            this.impares.Location = new System.Drawing.Point(19, 465);
            this.impares.Name = "impares";
            this.impares.Size = new System.Drawing.Size(98, 51);
            this.impares.TabIndex = 20;
            this.impares.Text = "que sume los numeros impares del 1 al n";
            this.impares.UseVisualStyleBackColor = true;
            this.impares.Click += new System.EventHandler(this.Impares_Click);
            // 
            // n
            // 
            this.n.Location = new System.Drawing.Point(150, 465);
            this.n.Name = "n";
            this.n.Size = new System.Drawing.Size(104, 51);
            this.n.TabIndex = 21;
            this.n.Text = "n: 111-222-333";
            this.n.UseVisualStyleBackColor = true;
            this.n.Click += new System.EventHandler(this.N_Click);
            // 
            // n1
            // 
            this.n1.Location = new System.Drawing.Point(304, 465);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(109, 51);
            this.n1.TabIndex = 22;
            this.n1.Text = "n: 333-222-111";
            this.n1.UseVisualStyleBackColor = true;
            this.n1.Click += new System.EventHandler(this.N1_Click);
            // 
            // n2
            // 
            this.n2.Location = new System.Drawing.Point(619, 461);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(100, 51);
            this.n2.TabIndex = 23;
            this.n2.Text = "n:1-22-333";
            this.n2.UseVisualStyleBackColor = true;
            this.n2.Click += new System.EventHandler(this.N2_Click);
            // 
            // n3
            // 
            this.n3.Location = new System.Drawing.Point(750, 398);
            this.n3.Name = "n3";
            this.n3.Size = new System.Drawing.Size(87, 63);
            this.n3.TabIndex = 24;
            this.n3.Text = "n:333-22-1";
            this.n3.UseVisualStyleBackColor = true;
            this.n3.Click += new System.EventHandler(this.N3_Click);
            // 
            // n4
            // 
            this.n4.Location = new System.Drawing.Point(619, 401);
            this.n4.Name = "n4";
            this.n4.Size = new System.Drawing.Size(87, 57);
            this.n4.TabIndex = 25;
            this.n4.Text = "que  marque decimal";
            this.n4.UseVisualStyleBackColor = true;
            this.n4.Click += new System.EventHandler(this.N4_Click);
            // 
            // letra
            // 
            this.letra.Location = new System.Drawing.Point(750, 465);
            this.letra.Name = "letra";
            this.letra.Size = new System.Drawing.Size(98, 47);
            this.letra.TabIndex = 26;
            this.letra.Text = "contar vocal,letra, espacio";
            this.letra.UseVisualStyleBackColor = true;
            this.letra.Click += new System.EventHandler(this.Letra_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(377, -6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 34);
            this.label1.TabIndex = 29;
            this.label1.Text = "PROYECTO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(324, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 34);
            this.label2.TabIndex = 30;
            this.label2.Text = "Erwin ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(447, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 34);
            this.label3.TabIndex = 31;
            this.label3.Text = "Vargas";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(584, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 34);
            this.label4.TabIndex = 32;
            this.label4.Text = "Montero";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(33, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 34);
            this.label5.TabIndex = 33;
            this.label5.Text = "docente";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(148, 34);
            this.label6.TabIndex = 34;
            this.label6.Text = "Estudiante";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(279, 157);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 34);
            this.label7.TabIndex = 35;
            this.label7.Text = "Ricardo";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(459, 157);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 34);
            this.label8.TabIndex = 36;
            this.label8.Text = "Quiroz";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(630, 157);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(113, 34);
            this.label9.TabIndex = 37;
            this.label9.Text = "Guzman";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(31, 37);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 34);
            this.label10.TabIndex = 38;
            this.label10.Text = "Materia";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(362, 37);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(180, 34);
            this.label11.TabIndex = 39;
            this.label11.Text = "Programacion";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(562, 37);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 34);
            this.label12.TabIndex = 40;
            this.label12.Text = "Basica";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(161, 37);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(25, 34);
            this.label13.TabIndex = 41;
            this.label13.Text = ":";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(166, 85);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(25, 34);
            this.label14.TabIndex = 42;
            this.label14.Text = ":";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(161, 157);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(25, 34);
            this.label15.TabIndex = 43;
            this.label15.Text = ":";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(886, 324);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 56);
            this.button4.TabIndex = 44;
            this.button4.Text = "eliminar espacios";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(886, 398);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 60);
            this.button7.TabIndex = 45;
            this.button7.Text = "eliminar la primera letra";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(995, 555);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.letra);
            this.Controls.Add(this.n4);
            this.Controls.Add(this.n3);
            this.Controls.Add(this.n2);
            this.Controls.Add(this.n1);
            this.Controls.Add(this.n);
            this.Controls.Add(this.impares);
            this.Controls.Add(this.categoria);
            this.Controls.Add(this.sueldo);
            this.Controls.Add(this.pares);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.vocal);
            this.Controls.Add(this.dias);
            this.Controls.Add(this.mayor3);
            this.Controls.Add(this.primos);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtpocitivo);
            this.Controls.Add(this.txtaprobado);
            this.Controls.Add(this.btntablaMultiplicar);
            this.Controls.Add(this.btnCalculadora);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Mi Calculadora";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnCalculadora;
        private System.Windows.Forms.Button btntablaMultiplicar;
        private System.Windows.Forms.Button txtaprobado;
        private System.Windows.Forms.Button txtpocitivo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button primos;
        private System.Windows.Forms.Button mayor3;
        private System.Windows.Forms.Button dias;
        private System.Windows.Forms.Button vocal;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button pares;
        private System.Windows.Forms.Button sueldo;
        private System.Windows.Forms.Button categoria;
        private System.Windows.Forms.Button impares;
        private System.Windows.Forms.Button n;
        private System.Windows.Forms.Button n1;
        private System.Windows.Forms.Button n2;
        private System.Windows.Forms.Button n3;
        private System.Windows.Forms.Button n4;
        private System.Windows.Forms.Button letra;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button7;
    }
}

