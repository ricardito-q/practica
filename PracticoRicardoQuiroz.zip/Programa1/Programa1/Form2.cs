﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void BtnSumar_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Me diste click");
            int resultado = 0;

            resultado = Convert.ToInt32(txbNum1.Text) + Convert.ToInt32(txbNum2.Text);

            //lblResultado.Text = Convert.ToString( resultado);

            lblResultado.Text = "El Resultado es: " + resultado.ToString();
        }
    }
}
