﻿namespace Programa1
{
    partial class Form16
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.cat1 = new System.Windows.Forms.RadioButton();
            this.cat2 = new System.Windows.Forms.RadioButton();
            this.cat3 = new System.Windows.Forms.RadioButton();
            this.cat4 = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(153, 188);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 56);
            this.button1.TabIndex = 0;
            this.button1.Text = "proceso";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // cat1
            // 
            this.cat1.AutoSize = true;
            this.cat1.Location = new System.Drawing.Point(28, 70);
            this.cat1.Name = "cat1";
            this.cat1.Size = new System.Drawing.Size(78, 17);
            this.cat1.TabIndex = 1;
            this.cat1.TabStop = true;
            this.cat1.Text = "categoria 1";
            this.cat1.UseVisualStyleBackColor = true;
            // 
            // cat2
            // 
            this.cat2.AutoSize = true;
            this.cat2.Location = new System.Drawing.Point(28, 111);
            this.cat2.Name = "cat2";
            this.cat2.Size = new System.Drawing.Size(78, 17);
            this.cat2.TabIndex = 2;
            this.cat2.TabStop = true;
            this.cat2.Text = "categoria 2";
            this.cat2.UseVisualStyleBackColor = true;
            // 
            // cat3
            // 
            this.cat3.AutoSize = true;
            this.cat3.Location = new System.Drawing.Point(28, 155);
            this.cat3.Name = "cat3";
            this.cat3.Size = new System.Drawing.Size(78, 17);
            this.cat3.TabIndex = 3;
            this.cat3.TabStop = true;
            this.cat3.Text = "categoria 3";
            this.cat3.UseVisualStyleBackColor = true;
            // 
            // cat4
            // 
            this.cat4.AutoSize = true;
            this.cat4.Location = new System.Drawing.Point(28, 208);
            this.cat4.Name = "cat4";
            this.cat4.Size = new System.Drawing.Size(78, 17);
            this.cat4.TabIndex = 4;
            this.cat4.TabStop = true;
            this.cat4.Text = "categoria 4";
            this.cat4.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(128, 275);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(128, 327);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 275);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "ingresar sueldo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 333);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "sueldo neto";
            // 
            // Form16
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 405);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.cat4);
            this.Controls.Add(this.cat3);
            this.Controls.Add(this.cat2);
            this.Controls.Add(this.cat1);
            this.Controls.Add(this.button1);
            this.Name = "Form16";
            this.Text = "Form16";
            this.Load += new System.EventHandler(this.Form16_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton cat1;
        private System.Windows.Forms.RadioButton cat2;
        private System.Windows.Forms.RadioButton cat3;
        private System.Windows.Forms.RadioButton cat4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}