﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int m;
            m = Convert.ToInt32(textBox1.Text);
            String n=" ";
            for (int c = 1; c <= m; c++)
            { n = n + " " + "-" + c * 5; }
            { label2.Text = n.ToString(); }
        }
    }
}
