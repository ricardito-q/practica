﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form19 : Form
    {
        public Form19()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int n;
            n = Convert.ToInt32(textBox1.Text);
            String t = "";
            for (int c = 1; c <= n; c++)
            {
                for (int s = 1; s <= n; s++)
                    t = c + " " + t.ToString();
            }
            { label2.Text = t.ToString(); }
        }
    }
}
