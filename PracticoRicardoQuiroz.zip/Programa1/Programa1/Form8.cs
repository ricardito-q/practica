﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Byte n1;
            n1 = byte.Parse(textBox1.Text);
            if (n1 <= 7)
                if (n1 == 1)
                { textBox2.Text = "lunes"; }
                else

            if (n1 == 2)
                { textBox2.Text = "martes"; }
                else
            if (n1 == 3)
                { textBox2.Text = "miercoles"; }
                else

            if (n1 == 4)
                { textBox2.Text = "jueves"; }
                else
            if (n1 == 5)
                { textBox2.Text = "viernes"; }
                else
            if (n1 == 6)
                { textBox2.Text = "sabado"; }
                else
            if (n1 == 7)
                { textBox2.Text = "domingo"; }
        }
    }
}
