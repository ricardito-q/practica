﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form17 : Form
    {
        public Form17()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int n;
            String suma = "";
            n = Convert.ToInt32(textBox1.Text);
            for (int c = 1; c <= n; c = c + 2)
            { suma = suma + "-" + c.ToString(); }
            { label2.Text = suma.ToString(); }
        }
    }
}
