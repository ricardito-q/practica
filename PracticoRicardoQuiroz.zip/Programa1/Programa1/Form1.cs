﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnSumar_Click(object sender, EventArgs e)
        {

        }

        private void ToolStripLabel1_Click(object sender, EventArgs e)
        {

        }

        private void BtnCalculadora_Click(object sender, EventArgs e)
        {
            var myForm = new Form2();
            myForm.Show();
        }

        private void BtntablaMultiplicar_Click(object sender, EventArgs e)
        {
            var myformtablamultiplicar = new tablademultiplicar();
            myformtablamultiplicar.Show();
        }

        private void Txtaprobado_Click(object sender, EventArgs e)
        {
            var myformtxtaprobado = new Form3();
            myformtxtaprobado.Show();
        }

        private void Txtpocitivo_Click(object sender, EventArgs e)
        {
            var myformpocitivo = new Form4();
            myformpocitivo.Show();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            var myformButton1 = new Form5();
            myformButton1.Show();
        }

        private void Primos_Click(object sender, EventArgs e)
        {
            var myformprimos = new Form6();
            myformprimos.Show();
        }

        private void Mayor3_Click(object sender, EventArgs e)
        {
            var myformmayor3 = new Form7();
            myformmayor3.Show();
        }

        private void Dias_Click(object sender, EventArgs e)
        {
            var myformdias = new Form8();
            myformdias.Show();
        }

        private void Vocal_Click(object sender, EventArgs e)
        {
            var myformvocal = new Form9();
            myformvocal.Show();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            var myformButton5 = new Form10();
            myformButton5.Show();
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            var myformButton6 = new Form11();
            myformButton6.Show();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            var myformButton2 = new Form12 ();
            myformButton2.Show();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            var myformButton3 = new Form13();
            myformButton3.Show();
        }

        private void Pares_Click(object sender, EventArgs e)
        {
            var myformPares = new Form14();
            myformPares.Show();
        }

        private void Sueldo_Click(object sender, EventArgs e)
        {
            var myformSueldo=new Form15();
            myformSueldo.Show();
        }

        private void Categoria_Click(object sender, EventArgs e)
        {
            var myformCategoria = new Form16();
            myformCategoria.Show();
        }

        private void Impares_Click(object sender, EventArgs e)
        {
            var myformImpares = new Form17();
            myformImpares.Show();
        }

        private void N_Click(object sender, EventArgs e)
        {
            var myformN = new Form18();
            myformN.Show();
        }

        private void N1_Click(object sender, EventArgs e)
        {
            var myformN1 = new Form19();
            myformN1.Show();
        }

        private void N2_Click(object sender, EventArgs e)
        {
            var myformN2 =  new Form20();
            myformN2.Show();
        }

        private void N3_Click(object sender, EventArgs e)
        {
            var myformN3 = new Form21();
            myformN3.Show();
        }

        private void N4_Click(object sender, EventArgs e)
        {
            var myformN4 = new Form22();
            myformN4.Show();
;        }

        private void Letra_Click(object sender, EventArgs e)
        {
            var myformLetra = new Form24();
            myformLetra.Show();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            var myformButton4 = new Form25();
            myformButton4.Show();
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            var myformButton7 = new Form26();
            myformButton7.Show();
        }
    }
}
