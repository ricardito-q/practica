﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class tablademultiplicar : Form
    {
        public tablademultiplicar()
        {
            InitializeComponent();
        }

        private void BtnProcesar_Click(object sender, EventArgs e)
        {
            
            var num = Convert.ToInt32(txtnum1.Text);
            var resultado = "";

            for (int i = 1; i <= 10; i++) {

                resultado = resultado + i.ToString() + " X " + num.ToString() + " = " + (i * num).ToString() + Environment.NewLine;

                  //  1 X 5 = 5
            }

            lblTabla.Text = resultado;


        }
    }
}
