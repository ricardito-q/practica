﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form16 : Form
    {
        public Form16()
        {
            InitializeComponent();
        }

        private void Form16_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int s;
            s = Convert.ToInt32(textBox1.Text);
            String c1 = "";
            if (cat1.Checked == true)
            {
                c1 = ((s * 11 / 100) + s).ToString();
                { textBox2.Text = c1.ToString(); }
            }
            else
            {
                if (cat2.Checked == true)
                    c1 = ((s * 10 / 100) + s).ToString();
                { textBox2.Text = c1.ToString(); }
            }

            {
                if (cat3.Checked == true)
                    c1 = ((s * 8 / 100) + s).ToString();
                { textBox2.Text = c1.ToString(); }
            }
            if (cat4.Checked == true)
                c1 = ((s * 7 / 100) + s).ToString();
            { textBox2.Text = c1.ToString(); }
        }
    }
}
