﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)

        {

        }
        private void Button1_Click(object sender, EventArgs e)
        { 
            ushort num;
            num = ushort.Parse(textBox1.Text);
            if(num%2==0)
            {
                textBox2.Text = "el numero es par";
            }
            else
            {
                textBox2.Text = "el numero es impar";
            }

        }
    }

    
}
