﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

            string letra = textBox1.Text;
            if ((letra == "a") || (letra == "e") || (letra == "i") || (letra == "o") || (letra == "u") ||
           (letra == "A") || (letra == "E") || (letra == "I") || (letra == "O") || (letra == "U"))


            { textBox2.Text = letra + " " + "es una vocal"; }

            else
            
            {
                textBox2.Text = "no es vocal";
            }
                   







        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
           

        }
    }
    
}
