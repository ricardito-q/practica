﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            bool esprimo;
            esprimo = true;
            int n;
            n = Int32.Parse(textBox1.Text);
            for (int c = 2; c < n; c++)
            {
                if (n % c == 0)

                {
                    esprimo = false;
                    break;
                }
            }
            label2.Text = "El número" + " " + n + " " + (esprimo ? "si" : "no") + " " + "Es número primo.";
        }
    }
}
