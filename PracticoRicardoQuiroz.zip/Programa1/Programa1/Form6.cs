﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            ushort num1, num2;
            num1 = ushort.Parse(textBox1.Text);
            num2 = ushort.Parse(textBox2.Text);
            if (num1 >= num2)
            {
                textBox3.Text = (num1)+"es mayor";
            }
            else
            {
                textBox3.Text = (num2) + "es mayor";
            }
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }
    }
}
