﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            ushort num1, num2, num3;
            num1 = ushort.Parse(textBox1.Text);
            num2 = ushort.Parse(textBox2.Text);
            num3 = ushort.Parse(textBox3.Text);
            if(num1>=num2)
                if(num1>=num3)
                {
                    textBox4.Text = (num1) + "es mayor";
                }
            else
                {
                    textBox4.Text = (num2) + "es mayor";
                }
            else
                if(num2>=num3)
            {
                textBox4.Text = (num2) + "es mayor";
            }
            else
            {
                textBox4.Text = (num3) + "es mayor";
            }
        }
    }
}
