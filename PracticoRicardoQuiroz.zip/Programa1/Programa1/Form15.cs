﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1
{
    public partial class Form15 : Form
    {
        float sueldobasico, bonificacion, incentivo, sueldoneto;

        private void Button2_Click(object sender, EventArgs e)
        {
            txtsb.Clear();
            txtb.Clear();
            txti.Clear();
            lblmostrar.Text = " ";

        }

        public Form15()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            sueldobasico = float.Parse(txtsb.Text);
            bonificacion = float.Parse(txtb.Text);
            incentivo = float.Parse(txtb.Text);
            sueldoneto = sueldobasico + bonificacion + incentivo;
            lblmostrar.Text = sueldoneto.ToString();
            

        }
    }
}
